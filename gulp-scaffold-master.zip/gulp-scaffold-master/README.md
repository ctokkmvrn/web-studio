# Gulp JS scaffold

Простой путь разработки с Jade и Stylus

sudo npm install -g

npm install

gulp watch для разработки

gulp build для сборки

